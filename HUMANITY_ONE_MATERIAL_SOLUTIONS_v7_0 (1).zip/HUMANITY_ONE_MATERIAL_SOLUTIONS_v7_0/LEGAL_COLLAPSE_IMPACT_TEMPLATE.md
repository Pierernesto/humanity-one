# Legal Collapse Impact Score Template

## Procedure / Law / Institutional Practice
Identify the barrier.

## Human Capability Harm
Which capabilities are harmed: health, access, economic safety, housing, medication, dignity, appeal rights.

## Delay Harm
How time worsens the case.

## Access Barrier
What the rule/procedure blocks.

## Correction Requested
Administrative correction, policy amendment, exception, funding route, urgent review.

## Evidence
Documents, dates, non-response log, cost of inaction.
