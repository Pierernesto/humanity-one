# Funding Request Template

## Applicant / Project
HUMANITY-ONE Material Solution Pathway.

## Problem
Define the material problem and population.

## Requested Amount
Local cost table reference.

## Use of Funds
Care access, medication, housing/food support, lab validation, trial access, pilot operations.

## Expected Outcome
K reduction, HFI increase, EFS increase, NRS reduction, access restored, referral completed.

## Measurement
Baseline, t30, t90.

## Public Benefit
Low-cost, universal-access, anti-capture implementation.
