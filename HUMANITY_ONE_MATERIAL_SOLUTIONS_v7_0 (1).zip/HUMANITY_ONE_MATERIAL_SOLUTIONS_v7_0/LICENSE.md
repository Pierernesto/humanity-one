# HUMANITY-ONE Anti-Capture Public Benefit License — Draft v7.0

Copyright (c) 2026 Pierernesto Di Paolo.

Use is permitted for research, public benefit, social-health implementation, non-predatory pilots, and institutional evaluation.

Forbidden uses:
- predatory commercialization of essential access;
- closed privatization of the HUMANITY-ONE Kernel;
- removal of safety, privacy, outcome, anti-capture, or public benefit controls;
- presenting unvalidated hypotheses as cures;
- unauthorized wet-lab, genetic, cellular, or clinical experimentation;
- use of the mark HUMANITY-ONE without authorization from Pierernesto Di Paolo.

This is a draft license for technical deposit and requires legal review before operational deployment.
