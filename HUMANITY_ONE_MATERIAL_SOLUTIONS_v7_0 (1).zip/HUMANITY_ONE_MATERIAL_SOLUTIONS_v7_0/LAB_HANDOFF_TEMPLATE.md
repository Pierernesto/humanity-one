# EDEN / Authorized Lab Handoff Template

## Boundary
This document is not a wet-lab protocol. It is a research handoff brief for authorized laboratories/institutions.

## 1. Unresolved Problem
Define the unmet clinical/biological problem.

## 2. Mechanism / Target
Describe candidate pathway, biological target, hallmark, disease mechanism, or unresolved hypothesis.

## 3. Existing Evidence
Evidence level E0–E5, sources, limitations.

## 4. Hypothesis
State the hypothesis to be evaluated.

## 5. Required Authorized Validation
Preclinical, computational, in vitro, ex vivo, animal, clinical-trial readiness, or other authorized pathway.

## 6. Safety Gate
List risks, non-permitted uses, and required approvals.

## 7. Outcome
Validated / not validated / requires revision / unsafe / insufficient evidence.
