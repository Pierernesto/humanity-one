# Public Responsibility Dossier Template

## 1. Problem
Describe the unresolved material problem.

## 2. Human Impact
Affected capability, K/HFI/EFS impact, urgency, irreversibility.

## 3. Existing Solution
Specify whether a solution exists: clinical, economic, social, legal, advanced therapy, trial, or research route.

## 4. Barrier
Cost, access, waiting time, legal/procedural barrier, institutional non-response, lack of funding.

## 5. Cost of Inaction
Expected worsening: health, mental health, housing, food, medication, disability, mortality, public cost.

## 6. Requested Public Action
Funding, appointment, housing/care support, trial access, policy correction, institutional evaluation.

## 7. Deadline
Set response deadline according to urgency.

## 8. Non-Response Accountability
If no response, record actor, date, mandate, and escalation route.
